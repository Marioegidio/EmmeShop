-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: emmeshop_db
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `venditore`
--

DROP TABLE IF EXISTS `venditore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `venditore` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `cognome` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `sesso` varchar(6) DEFAULT NULL,
  `telefono` varchar(15) NOT NULL,
  `via` varchar(45) NOT NULL,
  `città` varchar(45) NOT NULL,
  `cap` varchar(5) NOT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `Indirizzo` (`via`,`città`,`cap`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venditore`
--

LOCK TABLES `venditore` WRITE;
/*!40000 ALTER TABLE `venditore` DISABLE KEYS */;
INSERT INTO `venditore` VALUES ('55555','55555','fsdfsfsdf','sdfsdfss','dfsfsd@hmail','M','sdgsfg','gsdfgsdf','sdfgsdfg','55555'),('bkjb','khhvkhg','knkn','knkn','knkn@jjj.it','M','4555555555','knkn','nkn','55555'),('dfgsdfgsdf','sdfgsdfgdsfg','gsgs','sdgsfg','sgsfg@gmsgfmg.it','M','365','dfgsdfg','dfgdsfg','5656'),('egbgebebbe','ebbeebbeebbe','gsgfsg','dfgdfgdg','m.cetrangolo1@studenti.unisa.it','other','3402117514','grbergb','egbeb','84070'),('ergwergwewerger','gwergwerg','efwrtgwerg','ewrgewrerg','wergewrg@gerg','M','777777777','ergwegwerg','wergwergwerg','55555'),('fghdfghf','hgdfghdfgh','sfgsdfhdfg','sdhsdfghsdg','sdfhsgh@gdfgs','M','sdghfgh','shsfghfg','sghsfghs','55555'),('gsfgsdfg','sdgfgsdfghsdgh','sdgsgddsf','dsfgsdfgsddfgsdfg','dfgsdfgsd@dfsg','M','5454544545','dfgsdfg','dfgsdfg','55555'),('klnknlknl','nlnlnl','lmlmlm','lmlmlm','lmlmlm@gmail.com','M','3333333333','jhjhkjhjk','klhlkhjlh','55555'),('rttrertewrt','wertwertqwt','rwerw','werwerwe','wwerwrw@werwe.it','M','','werwer','werwerw','84070'),('rtyertyertye','tyertyeyey','ff','ff','cetrangolomario98@gmail.com','F','3402117514','ff','ff','84070'),('saaaa','asdasasdf','fgsdfg','sdfgsdfg','fsdf@gmail.com','M','355555555','dafasdf','sdgsafgs','88888'),('sdfgdfdg','sfdfgsfgs','fgdfg','dsfhsdh','sghdshsd@gmail.com','M','4546546444','dfgsdf','sdfgsdfg','84070'),('sdfsdfa','asdfasdf','xcvsv','dfbdsfb','dfbdfb7@sdfs','M','4546546444','sdfsf','sdfsdf','84070'),('sfbsfg','sdfsdfsdf','knjnjnjn','knkjnknkn','cetrangolomario98@gmail.com','M','4546546444','knkn','kmkmk','84070'),('v','v','55555','55555','55555@gmail.com','M','55555','c','c','55555'),('venditore1','venditore1','gianluca','paolini','afasfadfsg','F','5468557216','hvkgvdrsydvgfk','lun','46454');
/*!40000 ALTER TABLE `venditore` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-16 11:45:56
